global.y = 2;
x = 1;

console.log(`
global.y = 2;
x = 1;
`);

console.log("global.y => " + global.y);
console.log();
console.log("x => " + x);

