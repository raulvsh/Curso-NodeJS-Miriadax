'use strict'

global.y = 2;

console.log(`
global.y = 2;
`);

console.log("global.y => " + global.y);

