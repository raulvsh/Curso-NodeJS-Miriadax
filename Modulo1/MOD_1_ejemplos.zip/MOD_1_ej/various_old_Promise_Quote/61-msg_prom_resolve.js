
  Promise.resolve(
    "Hi Peter"
  )
  .then((msg) =>   
    console.log("Msg:" + msg)
  );

