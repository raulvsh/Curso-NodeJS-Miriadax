
  new Promise ((resolve, reject) =>
    resolve("Hi Peter")
  )
  .then((msg) =>   
    console.log("Msg:" + msg)
  );

