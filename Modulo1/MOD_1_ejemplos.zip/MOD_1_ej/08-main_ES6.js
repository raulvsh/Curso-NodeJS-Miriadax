
//    Module 1: executable file 06-main.js, imports circle.js

import {area} from './09-circle_ES6.js'; // path must start with './'

                //  => Area (radius 4): 50.26548245743669
console.log( 'Area (radius 4): ' + area(4));  
