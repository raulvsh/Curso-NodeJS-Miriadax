
console.log("This msg WILL be shown");

undefinedFunction(); // -> Execution error

console.log("This msg WON'T be shown");

