
var i;
for(i = 0; i < process.argv.length; i++) {
    console.log('Parameter ' + i + " = " + process.argv[i]) ;
}

