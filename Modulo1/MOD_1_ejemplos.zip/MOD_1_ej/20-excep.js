
console.log("This msg WILL be shown");

throw "Abort execution";

console.log("This msg WON'T be shown");

