
console.log(`\nEnumerable global properties
obtained with Object.keys(global):\n`);

console.log(Object.keys(global));

