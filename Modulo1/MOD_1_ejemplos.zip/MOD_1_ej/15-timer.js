
setTimeout(
  function(){
    console.log("Five seconds after");
  }, 
  5000
); 

console.log("The program starts");

