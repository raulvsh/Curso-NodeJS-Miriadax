
console.log();
console.log('__dirname:  ' + __dirname);
console.log();
console.log('__filename:  ' + __filename);

