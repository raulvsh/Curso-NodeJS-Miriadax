
//    Module 1: executable file 06-main.js, imports circle.js

var circle = require('./07-circle.js');    // path to 07-circle.js in the same directory is ./circulo.js

console.log( 'Area (radius 4): ' + circle.area(4));  //  => Area (radius 4): 50.26548245743669

